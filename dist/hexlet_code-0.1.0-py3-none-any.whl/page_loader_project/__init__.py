from page_loader_project.page_loader import download, get_file_name

__all__ = (
    'download',
    'get_file_name'
)
